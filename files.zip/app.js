document.addEventListener('DOMContentLoaded', function() {
  // เพิ่มโค้ดที่คุณให้มา
});